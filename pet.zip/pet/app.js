import React, { useState } from 'react';
import './style.css';



const App = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    visitDate: '',
    visitTime: '',
    visitors: '',
    petInterest: '',
    phone: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulate form submission
    setTimeout(() => {
      setSubmitted(true);
      sendConfirmationEmail();
    }, 1000);
  };

  const sendConfirmationEmail = () => {
    // Simulate sending an email
    console.log('Confirmation email sent to:', formData.email);
  };

  return (
    <div className="App">
      {!submitted ? (
        <form id="shelter-form" onSubmit={handleSubmit}>
          <div className="form-container" id="contact-form">
            <h2>Contact Shelter</h2>
            <input
              type="text"
              id="name"
              placeholder="Your Name"
              value={formData.name}
              onChange={handleChange}
              required
            />
            <input
              type="email"
              id="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <select
              id="subject"
              value={formData.subject}
              onChange={handleChange}
              required
            >
              <option value="">Select a subject</option>
              <option value="Adoption">Adoption</option>
              <option value="Volunteer">Volunteer</option>
            </select>
            <textarea
              id="message"
              placeholder="Message"
              value={formData.message}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-container" id="visit-form">
            <h2>Schedule Visit</h2>
            <input
              type="date"
              id="visitDate"
              value={formData.visitDate}
              onChange={handleChange}
              required
            />
            <input
              type="time"
              id="visitTime"
              value={formData.visitTime}
              onChange={handleChange}
              required
            />
            <input
              type="number"
              id="visitors"
              placeholder="Number of Visitors"
              value={formData.visitors}
              onChange={handleChange}
              required
            />
            <input
              type="text"
              id="petInterest"
              placeholder="Pet Interested In (optional)"
              value={formData.petInterest}
              onChange={handleChange}
            />
            <input
              type="tel"
              id="phone"
              placeholder="Contact Phone"
              value={formData.phone}
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit" className="submit-button">
            Submit
          </button>
        </form>
      ) : (
        <svg className="checkmark" viewBox="0 0 52 52" id="checkmark">
          <path fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8" />
        </svg>
      )}
    </div>
  );
};

export default App;